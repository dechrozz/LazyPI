-- FRAME SETUP BEGIN
-- Haupt-Frame erstellen
local LazyPIFrame = CreateFrame("Frame", "LazyPIFrame", UIParent, "BasicFrameTemplateWithInset")
LazyPIFrame:SetSize(460, 150) -- Breite angepasst, damit 5 Group Buttons nebeneinander passen
LazyPIFrame:SetPoint("TOP") -- Standardposition
LazyPIFrame:SetMovable(true)
LazyPIFrame:EnableMouse(true)
LazyPIFrame:RegisterForDrag("LeftButton")
LazyPIFrame:SetScript("OnDragStart", LazyPIFrame.StartMoving)
LazyPIFrame:SetScript("OnDragStop", LazyPIFrame.StopMovingOrSizing)

-- Das Frame soll standardmäßig versteckt sein
LazyPIFrame:Hide()

-- Titel
local title = LazyPIFrame:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
title:SetPoint("TOP", LazyPIFrame, "TOP", 0, -5)
title:SetText("PI Helper")
-- FRAME SETUP END



-- Tabelle für gespeicherte Einstellungen
LazyPISettings = LazyPISettings or {}

-- LANGUAGE SETTINGS BEGIN

-- Funktion zur Erkennung der Clientsprache
local function GetDefaultLanguage()
    local clientLocale = GetLocale()
    local localeMap = {
        deDE = "Deutsch",
        enUS = "English",
        esES = "Español",
        frFR = "Français",
        itIT = "Italiano",
        ptBR = "Português",
        ruRU = "Русский"
    }
    return localeMap[clientLocale] or "English" -- Fallback zu Englisch
end

-- Setze Clientsprache als Standard, wenn keine Einstellungen gespeichert sind
if not next(LazyPISettings) then
    local defaultLanguage = GetDefaultLanguage()
    LazyPISettings["language"] = defaultLanguage
end

-- Funktion zum Aktualisieren der Sprache
local function UpdateLanguage()
    local selectedLanguage = LazyPISettings["language"] or GetDefaultLanguage()
    title:SetText("LazyPI")
    print("Language updated to: " .. selectedLanguage)
end


--LANGUAGE SETTINGS END

--SPEC ROLE MAPPING BEGIN
-- Funktion zur Bestimmung der Rolle basierend auf der Spezialisierungs-ID
local function GetRoleBySpecID(specID)
    local specRoleMapping = {
        [62] = "DPS", [63] = "DPS", [64] = "DPS", -- Mage
        [65] = "HEALER", [66] = "TANK", [70] = "DPS", -- Paladin
        [71] = "DPS", [72] = "DPS", [73] = "TANK", -- Warrior
        [102] = "DPS", [103] = "DPS", [104] = "TANK", [105] = "HEALER", -- Druid
        [250] = "TANK", [251] = "DPS", [252] = "DPS", -- Death Knight
        [253] = "DPS", [254] = "DPS", [255] = "DPS", -- Hunter
        [256] = "HEALER", [257] = "HEALER", [258] = "DPS", -- Priest
        [259] = "DPS", [260] = "DPS", [261] = "DPS", -- Rogue
        [262] = "DPS", [263] = "DPS", [264] = "HEALER", -- Shaman
        [265] = "DPS", [266] = "DPS", [267] = "DPS", -- Warlock
        [268] = "TANK", [269] = "DPS", [270] = "HEALER", -- Monk
        [577] = "DPS", [581] = "TANK", -- Demon Hunter
        [1467] = "DPS", [1468] = "HEALER" -- Evoker
    }
    return specRoleMapping[specID] or "NONE" -- Standard: "NONE", falls keine Rolle zugeordnet ist
end

-- SPEC ROLE MAPPING END


-- TARGET BUTTON BEGIN

-- Target Button hinzufügen
local function CreateTargetButton()
    local button = CreateFrame("Button", "LazyPITargetButton", LazyPIFrame, "GameMenuButtonTemplate")
    button:SetHeight(30)
    button:SetPoint("TOP", LazyPIFrame, "TOP", 0, -30)
    button:SetText("Target")
    button:SetNormalFontObject("GameFontNormal")
    button:SetHighlightFontObject("GameFontHighlight")

    -- Funktion zur dynamischen Anpassung der Breite
    local function UpdateButtonWidth()
        local frameWidth = LazyPIFrame:GetWidth()
        button:SetWidth(frameWidth - 20)
    end

    -- Breite des Buttons anpassen, wenn das Frame aktualisiert wird
    LazyPIFrame:SetScript("OnSizeChanged", function()
        UpdateButtonWidth()
    end)

    -- Initiale Breite festlegen
    UpdateButtonWidth()

    button:SetScript("OnClick", function()
        local name, realm = UnitName("target")
        if name then
            local fullName = realm and realm ~= "" and (name .. "-" .. realm) or name
            local macroName = "LazyPI"
            local languageData = {
                enUS = { tooltip = "Power Infusion", cast = "/cast" },
                deDE = { tooltip = "Seele der Macht", cast = "/wirken" },
                esES = { tooltip = "Infusión de poder", cast = "/lanzar" },
                frFR = { tooltip = "Infusion de puissance", cast = "/lancer" },
                itIT = { tooltip = "Infusione di Potere", cast = "/cast" },
                ptBR = { tooltip = "Infusão de Poder", cast = "/lançar" },
                ruRU = { tooltip = "Придание сил", cast = "/применить" }
            }
            local clientLocale = GetLocale()
            local language = languageData[clientLocale] or languageData.enUS

            local macroBody = string.format(
                "#showtooltip %s\n/target %s\n%s %s\n/targetlasttarget",
                language.tooltip,
                fullName,
                language.cast,
                language.tooltip
            )

            local macroIndex = GetMacroIndexByName(macroName)
            if macroIndex == 0 then
                CreateMacro(macroName, "Spell_Holy_PowerInfusion", macroBody, true)
                print(string.format("Makro '%s' erstellt für %s.", macroName, fullName))
            else
                EditMacro(macroIndex, macroName, "Spell_Holy_PowerInfusion", macroBody)
                print(string.format("Makro '%s' aktualisiert für %s.", macroName, fullName))
            end
        else
            print("Kein Ziel ausgewählt.")
        end
    end)

    return button
end

local targetButton = CreateTargetButton()

-- TARGET BUTTON END


-- GROUP BUTTONS BEGIN

-- Funktion zur Erstellung eines Spielerbuttons
local function CreateGroupButton(index, unit)
    local button = CreateFrame("Button", "LazyPIGroupButton" .. index, LazyPIFrame, "GameMenuButtonTemplate")
    button:SetSize(80, 80)

    -- Positionierung der Buttons: Horizontal anordnen
    local row = math.floor((index - 1) / 5)
    local col = (index - 1) % 5
    button:SetPoint("TOPLEFT", LazyPIFrame, "TOPLEFT", 10 + col * 90, -60 - row * 90)

    -- Klassensymbol oben links
    button.classIcon = button:CreateTexture(nil, "ARTWORK")
    button.classIcon:SetSize(24, 24)
    button.classIcon:SetPoint("TOPLEFT", button, "TOPLEFT", 12, -20)

    -- Spezialisierungssymbol oben rechts
    button.specIcon = button:CreateTexture(nil, "ARTWORK")
    button.specIcon:SetSize(24, 24)
    button.specIcon:SetPoint("TOPRIGHT", button, "TOPRIGHT", -12, -20)

    -- Spielername unten
    button.nameText = button:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    button.nameText:SetPoint("BOTTOM", button, "BOTTOM", 0, 16)

    -- Spielername und Realmname aufteilen
    local name, realm = UnitName(unit)
    button.nameText:SetText(name or "Unknown")

    -- Spezialisierungssymbol setzen
    if unit == "player" then
        local specIndex = GetSpecialization()
        if specIndex then
            local _, _, _, specIcon = GetSpecializationInfo(specIndex)
            button.specIcon:SetTexture(specIcon)
        else
            button.specIcon:SetTexture(nil)
        end
    else
        local specID = GetInspectSpecialization(unit)
        if specID and specID > 0 then
            local _, _, _, specIcon = GetSpecializationInfoByID(specID)
            button.specIcon:SetTexture(specIcon)
        else
            NotifyInspect(unit)
            button.specIcon:SetTexture(nil)
        end
    end



    -- Klassensymbol setzen
    local _, class = UnitClass(unit)
    if class then
        button.classIcon:SetTexture("Interface\\GLUES\\CHARACTERCREATE\\UI-CHARACTERCREATE-CLASSES")
        local texCoords = CLASS_ICON_TCOORDS[class]
        if texCoords then
            button.classIcon:SetTexCoord(unpack(texCoords))
        else
            button.classIcon:SetTexCoord(0, 1, 0, 1) -- Fallback
        end
    else
        button.classIcon:SetTexture(nil)
    end

    -- Button-Klick-Verhalten
    button:SetScript("OnClick", function()
        if name then
            local fullName = realm and realm ~= "" and (name .. "-" .. realm) or name
            local macroName = "LazyPI"
            local languageData = {
                enUS = { tooltip = "Power Infusion", cast = "/cast" },
                deDE = { tooltip = "Seele der Macht", cast = "/wirken" },
                esES = { tooltip = "Infusión de poder", cast = "/lanzar" },
                frFR = { tooltip = "Infusion de puissance", cast = "/lancer" },
                itIT = { tooltip = "Infusione di Potere", cast = "/cast" },
                ptBR = { tooltip = "Infusão de Poder", cast = "/lançar" },
                ruRU = { tooltip = "Придание сил", cast = "/применить" }
            }
            local clientLocale = GetLocale()
            local language = languageData[clientLocale] or languageData.enUS

            local macroBody = string.format(
                "#showtooltip %s\n/target %s\n%s %s\n/targetlasttarget",
                language.tooltip,
                fullName,
                language.cast,
                language.tooltip
            )

            local macroIndex = GetMacroIndexByName(macroName)
            if macroIndex == 0 then
                CreateMacro(macroName, "Spell_Holy_PowerInfusion", macroBody, true)
                print(string.format("Makro '%s' erstellt für %s.", macroName, fullName))
            else
                EditMacro(macroIndex, macroName, "Spell_Holy_PowerInfusion", macroBody)
                print(string.format("Makro '%s' aktualisiert für %s.", macroName, fullName))
            end
        else
            print("Kein Spieler ausgewählt.")
        end
    end)

    return button
end


-- GROUP BUTTONS BEGIN

-- Rollensymbole definieren
local roleIcons = {
    TANK = "Interface\\Addons\\LazyPI\\Textures\\roleSymbols\\tankRole.tga",
    HEALER = "Interface\\Addons\\LazyPI\\Textures\\roleSymbols\\healerRole.tga",
    DPS = "Interface\\Addons\\LazyPI\\Textures\\roleSymbols\\dpsRole.tga",
    NONE = nil
}

-- Funktion zur Erstellung eines Spielerbuttons
local function CreateGroupButton(index, unit)
    local button = CreateFrame("Button", "LazyPIGroupButton" .. index, LazyPIFrame, "GameMenuButtonTemplate")
    button:SetSize(80, 80)

    -- Positionierung
    local row = math.floor((index - 1) / 5)
    local col = (index - 1) % 5
    button:SetPoint("TOPLEFT", LazyPIFrame, "TOPLEFT", 10 + col * 90, -60 - row * 90)

    -- Klassensymbol
    button.classIcon = button:CreateTexture(nil, "ARTWORK")
    button.classIcon:SetSize(24, 24)
    button.classIcon:SetPoint("TOPLEFT", button, "TOPLEFT", 12, -20)

    -- Rollensymbol
    button.roleIcon = button:CreateTexture(nil, "ARTWORK")
    button.roleIcon:SetSize(24, 24)
    button.roleIcon:SetPoint("TOPRIGHT", button, "TOPRIGHT", -12, -20)

    -- Spielername
    button.nameText = button:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    button.nameText:SetPoint("BOTTOM", button, "BOTTOM", 0, 16)
    local name, realm = UnitName(unit)
    button.nameText:SetText(name or "Unknown")

    -- Klassensymbol setzen
    local _, class = UnitClass(unit)
    if class then
        button.classIcon:SetTexture("Interface\\GLUES\\CHARACTERCREATE\\UI-CHARACTERCREATE-CLASSES")
        local texCoords = CLASS_ICON_TCOORDS[class]
        if texCoords then
            button.classIcon:SetTexCoord(unpack(texCoords))
        else
            button.classIcon:SetTexCoord(0, 1, 0, 1)
        end
    else
        button.classIcon:SetTexture(nil)
    end

    -- Rollensymbol setzen
    if unit == "player" then
        local specIndex = GetSpecialization()
        if specIndex then
            local specID = select(1, GetSpecializationInfo(specIndex))
            local role = GetRoleBySpecID(specID)
            button.roleIcon:SetTexture(roleIcons[role])
        else
            button.roleIcon:SetTexture(nil)
        end
    else
        local specID = GetInspectSpecialization(unit)
        if specID and specID > 0 then
            local role = GetRoleBySpecID(specID)
            button.roleIcon:SetTexture(roleIcons[role])
        else
            local fallbackRole = UnitGroupRolesAssigned(unit)
            button.roleIcon:SetTexture(roleIcons[fallbackRole] or nil)
        end
    end

        -- Button-Klick-Verhalten
        button:SetScript("OnClick", function()
            if name then
                local fullName = realm and realm ~= "" and (name .. "-" .. realm) or name
                local macroName = "LazyPI"
                local languageData = {
                    enUS = { tooltip = "Power Infusion", cast = "/cast" },
                    deDE = { tooltip = "Seele der Macht", cast = "/wirken" },
                    esES = { tooltip = "Infusión de poder", cast = "/lanzar" },
                    frFR = { tooltip = "Infusion de puissance", cast = "/lancer" },
                    itIT = { tooltip = "Infusione di Potere", cast = "/cast" },
                    ptBR = { tooltip = "Infusão de Poder", cast = "/lançar" },
                    ruRU = { tooltip = "Придание сил", cast = "/применить" }
                }
                local clientLocale = GetLocale()
                local language = languageData[clientLocale] or languageData.enUS
    
                local macroBody = string.format(
                    "#showtooltip %s\n/target %s\n%s %s\n/targetlasttarget",
                    language.tooltip,
                    fullName,
                    language.cast,
                    language.tooltip
                )
    
                local macroIndex = GetMacroIndexByName(macroName)
                if macroIndex == 0 then
                    CreateMacro(macroName, "Spell_Holy_PowerInfusion", macroBody, true)
                    print(string.format("Makro '%s' erstellt für %s (%s).", macroName, fullName, clientLocale))
                else
                    EditMacro(macroIndex, macroName, "Spell_Holy_PowerInfusion", macroBody)
                    print(string.format("Makro '%s' aktualisiert für %s (%s).", macroName, fullName, clientLocale))
                end
            else
                print("Kein Spieler ausgewählt.")
            end
        end)
    

    return button
end


-- Funktion zum Sortieren der Gruppenmitglieder
local function SortGroupMembers(groupMembers)
    local rolePriority = { TANK = 1, HEALER = 2, DPS = 3, NONE = 4 }

    table.sort(groupMembers, function(a, b)
        local roleA = rolePriority[a.role or "NONE"] or 4 -- Fallback zu NONE
        local roleB = rolePriority[b.role or "NONE"] or 4 -- Fallback zu NONE

        if roleA == roleB then
            return (a.name or "") < (b.name or "") -- Alphabetisch sortieren, wenn Rollen gleich sind
        else
            return roleA < roleB
        end
    end)
end





-- Funktion zur Aktualisierung der Gruppenmitglieder
local function UpdateGroupButtons()
    -- Entferne alte Buttons
    if LazyPIFrame.groupButtons then
        for _, button in ipairs(LazyPIFrame.groupButtons) do
            button:Hide()
            button:SetParent(nil)
        end
    end

    LazyPIFrame.groupButtons = {}

    local groupMembers = {}

    if IsInGroup() then
        local numGroupMembers = GetNumGroupMembers()
        for i = 1, numGroupMembers do
            local unit = (i == numGroupMembers) and "player" or "party" .. i
            if UnitExists(unit) then
                local name = UnitName(unit)
                local role = UnitGroupRolesAssigned(unit) -- Standardrollen
                local specID = GetInspectSpecialization(unit)

                -- Fallback auf Inspektion für genauere Rollendaten
                if specID and specID > 0 then
                    role = GetRoleBySpecID(specID)
                end

                table.insert(groupMembers, { unit = unit, name = name, role = role })
            end
        end
    else
        -- Solo-Spieler
        local name = UnitName("player")
        local role = UnitGroupRolesAssigned("player")
        local specID = GetInspectSpecialization("player")

        if specID and specID > 0 then
            role = GetRoleBySpecID(specID)
        end

        table.insert(groupMembers, { unit = "player", name = name, role = role })
    end

    -- Sortiere Mitglieder
    SortGroupMembers(groupMembers)

    -- Erstelle Buttons
    for i, member in ipairs(groupMembers) do
        local button = CreateGroupButton(i, member.unit)

        -- Rollensymbol setzen
        if member.role and roleIcons[member.role] then
            button.roleIcon:SetTexture(roleIcons[member.role])
        else
            button.roleIcon:SetTexture(nil)
        end

        table.insert(LazyPIFrame.groupButtons, button)
    end
end

-- Inspektionsereignisse registrieren
local inspectFrame = CreateFrame("Frame")
inspectFrame:RegisterEvent("INSPECT_READY")
inspectFrame:SetScript("OnEvent", function(_, _, guid)
    for _, button in ipairs(LazyPIFrame.groupButtons or {}) do
        if UnitExists(button.unit) and UnitGUID(button.unit) == guid then
            local specID = GetInspectSpecialization(button.unit)
            if specID and specID > 0 then
                local role = GetRoleBySpecID(specID)
                if roleIcons[role] then
                    button.roleIcon:SetTexture(roleIcons[role])
                else
                    button.roleIcon:SetTexture(nil)
                end
            end
        end
    end
end)

-- Ereignis-Handler für Gruppenänderungen
local groupEventFrame = CreateFrame("Frame")
groupEventFrame:RegisterEvent("GROUP_ROSTER_UPDATE")
groupEventFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
groupEventFrame:SetScript("OnEvent", function()
    UpdateGroupButtons()
end)


-- GROUP BUTTONS END


-- EVENT BEGIN

local eventFrame = CreateFrame("Frame")
eventFrame:RegisterEvent("GROUP_ROSTER_UPDATE")
eventFrame:RegisterEvent("PLAYER_ENTERING_WORLD")

eventFrame:SetScript("OnEvent", function(_, event)
    if event == "GROUP_ROSTER_UPDATE" then
        if IsInGroup() then
            LazyPIFrame:Show()
            UpdateGroupButtons()
        else
            if LazyPIFrame:IsShown() then
                LazyPIFrame:Hide()
            end
        end
    elseif event == "PLAYER_ENTERING_WORLD" then
        UpdateGroupButtons()
    end
end)

-- EVENT END





-- Initiale Sprache festlegen
UpdateLanguage()

-- Slash-Befehl registrieren
SLASH_LAZYPI1 = "/LPI"
SLASH_LAZYPI2 = "/lpi"
SlashCmdList["LAZYPI"] = function()
    if LazyPIFrame:IsShown() then
        LazyPIFrame:Hide()
        print("LazyPI geschlossen.")

    else
        LazyPIFrame:Show()
        UpdateGroupButtons() -- Buttons aktualisieren, wenn das Frame geöffnet wird
        print("LazyPI geöffnet.")
    end
end


print("LazyPI geladen! Tippe /LPI oder /lpi , um das Fenster zu öffnen.")

